# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ExpenseReporting::Application.config.secret_token = 'e8fa55dc3421956ca70bb801d61244a9c9e051af6ac683470407c4d74c1208fb6b13f48b4295e0ddf9f03e1b8a19106e1de50c7dbf42af25fede9ba14012ad03'
