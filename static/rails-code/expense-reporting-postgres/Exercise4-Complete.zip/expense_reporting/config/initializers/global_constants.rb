USER_ROLES = %w[admin user]

EXPENSE_STATUS = %w[pending accepted rejected]