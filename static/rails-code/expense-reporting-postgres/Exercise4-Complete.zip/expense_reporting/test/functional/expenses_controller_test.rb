require 'test_helper'

class ExpensesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
