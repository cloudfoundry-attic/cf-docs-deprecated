require 'test_helper'

class ExpenseTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
