# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsExpenseReportMongo::Application.config.secret_token = '7be84361db325d57311ff87b1da4da0b6daef3015c8cf51701c5708e3697145f8a452448e120f6b64350a7d5758811f57e8371bced5aa3353357c54e8cc8c4d0'
