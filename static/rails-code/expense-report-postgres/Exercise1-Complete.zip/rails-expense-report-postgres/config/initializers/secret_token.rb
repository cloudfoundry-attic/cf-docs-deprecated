# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RailsExpenseReportPostgres::Application.config.secret_token = 'a9c839a308ded08cf6fccfaaad2456dede86ebf10c4820052275db68328369b52bffc711806faf3d0929ccdedd4790999b47ae66a0039af04f0bf92f4224929a'
