/**
 * main.js
 * About this : This is the main javascript file to handle adding, editing, deleting all elements on canvas (text, rectangle, circle etc)
 * Uses 'Fabric.js' library for client side
 * Node.js and  Node Package Manager (NPM) for server side - JavaScript environment that uses an asynchronous event-driven model.
 */
var whiteboardApp = {
    chatDivElement: null,
    chatInputElement: null,
    currentIcon: null,
    userName: 'Guest',

    init: function () {
        this.initCanvas();
        this.initToolbar();
        this.initChatWindow();
        this.initShowPrompt();
    },


    initToolbar: function () {
        var tb = $("#shapesToolbar").toolbar(
            {
                shapes:whiteboardApp.shapes, // shapes object with shape 'name' and 'iconname' ex: shapes = {  rectangle: {  name: 'rectangle', imagesPath:'/static/images/' } }
                dropTarget:$('.ui-canvas'),
                title:'Shapes',
                shapeSelected:this.onShapeSelect,  // callback
                dropTargetClicked:this.onClickDropTarget   //callback
            }
        );
    },

    initChatWindow: function() {
        whiteboardApp.chatWidget = $(".chat-div").chatwindow(
            {
                title: "Chat",
                textSubmitted:this.onTextSubmit
            } );
    },

    initCanvas:function() {
        whiteboardApp.canvasWidgetInstance = $("#canvas-holder").canvas(
            {
                title: "Canvas",
                fabric: fabric,
                shapeModified: this.onShapeModify,
                applyModify: this.onApplyModify,
                shapeDeleted: this.onShapeDelete
            } );

        whiteboardApp.canvas = whiteboardApp.canvasWidgetInstance.canvas("getCanvasInstance");
    },
    initShowPrompt: function () {
        window.showPrompt = function () {
            do {
                whiteboardApp.userName = prompt("Please enter your name( 4 to 15 chars)");
            }
            while (whiteboardApp.userName === null || whiteboardApp.userName.length < 4 || whiteboardApp.userName.length > 15);
            $('#username').text(whiteboardApp.userName);
        };
        window.showPrompt();
    }

}; //end of app