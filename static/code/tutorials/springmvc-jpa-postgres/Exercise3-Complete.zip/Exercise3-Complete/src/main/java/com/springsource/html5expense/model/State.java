package com.springsource.html5expense.model;

public enum State {
    NEW,

    OPEN,

    IN_REVIEW,

    REJECTED,

    APPROVED
}
